package com.nawtovi.simondice.Modelo;

import com.nawtovi.simondice.R;

import java.util.ArrayList;

/**
 * Created by Yo on 13/11/2016.
 */

public class Color implements IControlColor{

    //Rojo, verde, azul, amarillo
    private int lightColors[] = {R.color.redLight,R.color.greenLight,R.color.blueLight,R.color.yellowLight};
    private int darkColors[] = {R.color.redDark,R.color.greenDark,R.color.blueDark, R.color.yellowDark};
    private final int COLORES[]={0,1,2,3};
    private ArrayList<Integer> secuencia;

    @Override
    public ArrayList crearSecuenciaNueva() {
        secuencia=new ArrayList<>();
        secuencia.add(COLORES[(int)(Math.random()*COLORES.length-1)]);
        return secuencia;
    }

    @Override
    public ArrayList anadirNotaSecuencia(ArrayList secuencia) {
        secuencia.add(COLORES[(int)(Math.random()*COLORES.length-1)]);
        return secuencia;
    }

    @Override
    public boolean comprobarPosicion(int color, ArrayList secuencia, int orden) {
            return (Integer)color==secuencia.get(orden);
    }

    public int getDarkColors(int pos) {
        return darkColors[pos];
    }

    public int getLightColors(int pos) {
        return lightColors[pos];
    }
}
