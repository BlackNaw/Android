package com.nawtovi.simondice.Modelo;

import java.util.ArrayList;

/**
 * Created by Yo on 13/11/2016.
 */

public interface IControlColor {
    public ArrayList crearSecuenciaNueva();
    public ArrayList anadirNotaSecuencia(ArrayList secuencia);
    public boolean comprobarPosicion(int color, ArrayList secuencia, int orden);
}
