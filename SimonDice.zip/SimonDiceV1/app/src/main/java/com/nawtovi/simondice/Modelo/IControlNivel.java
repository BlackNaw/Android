package com.nawtovi.simondice.Modelo;

/**
 * Created by Yo on 11/11/2016.
 */

public interface IControlNivel {
    public Nivel incrementarNivel(Nivel nivel);
}
