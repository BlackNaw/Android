package com.nawtovi.simondice.Modelo;

/**
 * Created by jose on 15/11/2016.
 */


public class Circle {

    private float radius;
    private float centerX;
    private float centerY;

    public Circle(float coordenateX, float coordenateY, float radius) {

        this.centerY=coordenateY;
        this.centerX=coordenateX;
        this.radius = radius;
        System.out.println("CenterX= "+this.centerX+" "+"CenterY= "+this.centerY);
        System.out.println("Radio = "+radius);

    }


    public double isTouching(float currentX, float currentY) {
        System.out.println("Distancia al centro= "+Math.sqrt(Math.pow(currentX - centerX, 2.0)+Math.pow(currentY - centerY, 2.0)));
        return Math.sqrt(Math.pow(currentX - centerX, 2.0)+Math.pow(currentY - centerY, 2.0));
    }

//    public boolean isTocuhingInnerCircle(float currentX, float currentY, Circle innerCircle) {
//        if (isTouching(currentX, currentY)) {
//            return !(Math.sqrt(Math.pow(currentX - innerCircle.centerX, 2.0) + Math.pow(currentY - innerCircle.centerY, 2.0)) < innerCircle.radius);
//        }
//        return false;
//    }
}
