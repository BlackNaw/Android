package com.nawtovi.simondice.Modelo;

/**
 * Created by Yo on 11/11/2016.
 */
public class Nivel implements IControlNivel {

    private int dificultad;
    private int logintud;
    private long pausa;

    public Nivel(int dificultad, int logintud, long pausa) {
        this.dificultad = dificultad;
        this.logintud = logintud;
        this.pausa = pausa;
    }

    public Nivel() {
        this.dificultad =1;
        this.logintud=5;
        this.pausa=700;
    }

    @Override
    public Nivel incrementarNivel(Nivel nivel) {
        nivel.dificultad++;
        nivel.logintud+=5;
        nivel.pausa-=70;
        return nivel;
    }

    public int getDificultad() {
        return dificultad;
    }

    public int getLogintud() {
        return logintud;
    }

    public long getPausa() {
        return pausa;
    }
}
