package com.nawtovi.simondice.Principal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Space;
import android.widget.TextView;

import com.nawtovi.simondice.R;

public class MainActivity extends AppCompatActivity {

    private Button iniciar;
    private View[] botones = new Button[4];
    private  Space spacios[] = new Space[2];
    private GridLayout grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        grid=(GridLayout)findViewById(R.id.gridButtons);
        TextView texto=(TextView)findViewById(R.id.txtPuntuacion);
        System.out.println(grid.getWidth());
//        texto.setText(String.valueOf(grid.getWidth()));

    }
//        fillViews();
//
//        iniciar.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                v.setVisibility(View.INVISIBLE);
//                Nivel level = new Nivel();
//                TextView[] textView = new TextView[2];
//                textView[0] = (TextView) findViewById(R.id.txtNivel);
//                textView[1] = (TextView) findViewById(R.id.txtPuntuacion);
//               ControlSimon control = new ControlSimon(botones, level, textView);
//                control.start();
//            }
//        });
//
//        Display display = getWindowManager().getDefaultDisplay();
//        int width = display.getWidth() / 12;
//
//        spacios[0].setMinimumHeight(width);
//        spacios[1].setMinimumHeight(width);
//    }
//
//    private void fillViews() {
//        spacios[0] = (Space) findViewById(space1);
//        spacios[1] = (Space) findViewById(space2);
//
//        iniciar = (Button) findViewById(R.id.btnIniciar);
//
//        botones[0] = findViewById(R.id.button1);
//        botones[1] = findViewById(R.id.button2);
//        botones[2] = findViewById(R.id.button3);
//        botones[3] = findViewById(R.id.button4);
//    }
}
