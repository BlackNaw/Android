package com.nawtovi.simondice.Control;

import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import com.nawtovi.simondice.Modelo.Color;
import com.nawtovi.simondice.Modelo.Nivel;

import java.util.ArrayList;

/**
 * Created by Yo on 14/11/2016.
 */

public class ControlSimon extends Thread implements IControlSimon {

    private ArrayList<Integer> secuencia;
    private Color color;
    private Nivel nivel;
    private View[] botones;
    private TextView[] textos;
    Handler escribirEnUI = new Handler();
    private boolean parado = true;

    public ControlSimon(View v[], Nivel nivel, TextView[] text) {
        this.nivel = nivel;
        this.botones = v;
        this.textos = text;
        color = new Color();
        secuencia = color.crearSecuenciaNueva();
    }

    @Override
    public synchronized void run() {
        while (true) {
            if (parado)
                for (int i = 0; i < secuencia.size(); i++) {
                    final int FINAL_I = secuencia.get(i);
                    final int FINAL_COLOR_CLARO = color.getLightColors(secuencia.get(i));
                    final int FINAL_COLOR_OSCURO = color.getDarkColors(secuencia.get(i));
                    reproducirSecuenciaOriginal(FINAL_I, FINAL_COLOR_CLARO);
                    try {
                        sleep(nivel.getPausa());
                        reproducirSecuenciaOriginal(FINAL_I, FINAL_COLOR_OSCURO);
                        sleep(nivel.getPausa());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            this.parado=false;
        }
    }

    @Override
    public synchronized void reproducirSecuenciaOriginal(final int boton, final int color) {
        escribirEnUI.post(new Runnable() {
            @Override
            public void run() {
                botones[boton].setBackgroundTintList(botones[boton].getResources().getColorStateList(color, null));
            }
        });
    }

    @Override
    public boolean comprobarFinSecuenciaUsuario(int orden, Nivel nivel) {
        return false;
    }
}
