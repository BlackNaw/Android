package com.nawtovi.simondice.Principal;

import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nawtovi.simondice.Control.ControlSimon;
import com.nawtovi.simondice.Modelo.Circle;
import com.nawtovi.simondice.Modelo.Nivel;
import com.nawtovi.simondice.R;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    ImageView[] botones = new ImageView[5];
    TextView[] textView = new TextView[2];
    Circle circle;
    private MediaPlayer[] sounds = new MediaPlayer[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        textView[0] = (TextView) findViewById(R.id.txtNivel);
        textView[1] = (TextView) findViewById(R.id.textPuntuacion);

        botones[0] = (ImageView) findViewById(R.id.imgRed);
        botones[1] = (ImageView) findViewById(R.id.imgBlue);
        botones[2] = (ImageView) findViewById(R.id.imgGreen);
        botones[3] = (ImageView) findViewById(R.id.imgYellow);
        botones[4] = (ImageView) findViewById(R.id.imgCenter);


        sounds[0] = MediaPlayer.create(this, R.raw.sound1);
        sounds[1] = MediaPlayer.create(this, R.raw.sound2);
        sounds[2] = MediaPlayer.create(this, R.raw.sound3);
        sounds[3] = MediaPlayer.create(this, R.raw.sound4);
        sounds[4] = MediaPlayer.create(this, R.raw.bocina);

        //Al abrir el juego desactivamos todos los botones menos el central (que inicia el juego)
        for (int i = 0; i < botones.length - 1; i++) {
            botones[i].setEnabled(false);
        }
        //Ponemos a todas las imagenes el action listener
        for (int i = 0; i < botones.length; i++) {
            botones[i].setOnTouchListener(this);
        }

        //Pongo un action listener para iniciar
        botones[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Cuando el juego activamos todos los botones y desactivamos el central
                for (int i = 0; i < botones.length - 1; i++) {
                    botones[i].setEnabled(true);
                    sounds[4].start();
                }
                botones[4].setEnabled(false);
            }
        });


    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        //Comienza juego
        int accion = event.getAction();

        if (accion == MotionEvent.ACTION_UP) {
            Nivel level = new Nivel();
            ControlSimon control = new ControlSimon(botones, level, textView);


            //Obtenemos el boton pulsado
            int elemento = wichIsToching(event, v);

            //Asignamos un sonido
            switch (elemento) {
                case 1:
                    sounds[0].start();
                    break;
                case 2:
                    sounds[1].start();
                    break;
                case 3:
                    sounds[2].start();
                    break;
                case 4:
                    sounds[3].start();
                    break;
            }
            textView[0].setText(Integer.toString(elemento));

//        botones[0].setImageAlpha(100);

            control.start();

        }
        return false;
    }

    private int wichIsToching(MotionEvent event, View v) {

        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.relativeLayout);

        float centerX = gridLayout.getLeft() + metrics.widthPixels - relativeLayout.getWidth() + (gridLayout.getWidth() / 2);
        float centerY = gridLayout.getTop() + metrics.heightPixels - relativeLayout.getHeight() + (gridLayout.getHeight() / 2);
        float radius = (gridLayout.getHeight() <= gridLayout.getWidth()) ? gridLayout.getHeight() / 2 : gridLayout.getWidth() / 2;
        double masterRadius;
        circle = new Circle(centerX, centerY, radius);
        int elemento = 0;
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if ((masterRadius = circle.isTouching(event.getRawX(), event.getRawY())) < radius) {
                if (masterRadius < botones[4].getWidth() / 2 && botones[4].isEnabled()) {
                    elemento = 5;
                } else if (masterRadius > botones[4].getWidth() / 2) {
                    elemento = Integer.valueOf((v.getResources().getResourceEntryName(v.getId())).substring(9, 10));
                }
            }
        }
        Log.d("Elemento", String.valueOf(elemento));
        return elemento;
    }

}
