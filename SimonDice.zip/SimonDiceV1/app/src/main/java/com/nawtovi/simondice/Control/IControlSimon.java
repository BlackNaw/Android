package com.nawtovi.simondice.Control;


import com.nawtovi.simondice.Modelo.Nivel;

/**
 * Created by Yo on 11/11/2016.
 */

public interface IControlSimon {

    public void reproducirSecuenciaOriginal(int color, int boton);

    public boolean comprobarFinSecuenciaUsuario(int orden,Nivel nivel);

}
