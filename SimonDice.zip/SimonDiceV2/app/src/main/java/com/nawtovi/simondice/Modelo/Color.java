package com.nawtovi.simondice.Modelo;

import java.util.ArrayList;

/**
 * Created by Yo on 13/11/2016.
 */

public class Color implements IControlColor{

    //Rojo, verde, azul, amarillo
    final int FINAL_LIGHT_COLOR = 0;
    final int FINAL_DARK_COLOR = 255;
    private final int COLORES[]={0,1,2,3};
    private ArrayList<Integer> secuencia;

    @Override
    public ArrayList crearSecuenciaNueva() {
        secuencia=new ArrayList<>();
        secuencia.add(COLORES[(int)(Math.random()*COLORES.length-1)]);
        return secuencia;
    }

    @Override
    public ArrayList anadirNotaSecuencia(ArrayList secuencia) {
        secuencia.add(COLORES[(int)(Math.random()*COLORES.length-1)]);
        return secuencia;
    }

    @Override
    public boolean comprobarPosicion(int color, ArrayList secuencia, int orden) {
            return (Integer)color==secuencia.get(orden);
    }

    public int getDarkColor() {
        return FINAL_DARK_COLOR;
    }

    public int getLightColor() {
        return FINAL_LIGHT_COLOR;
    }
}
